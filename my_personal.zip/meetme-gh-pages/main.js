function hi() {
  console.log('hi')
}